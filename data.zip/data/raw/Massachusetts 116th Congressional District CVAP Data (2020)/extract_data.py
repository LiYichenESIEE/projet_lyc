import geopandas as gpd
import pandas as pd
import os

def extract_shapefile_attributes_to_csv(directory):
    """
    自动遍历指定目录下的所有 .shp 文件，提取属性数据并保存为 .csv 文件
    :param directory: 包含 .shp 文件的目录
    """
    # 遍历目录下的所有文件
    for filename in os.listdir(directory):
        # 如果文件是 .shp 文件
        if filename.endswith(".shp"):
            # 构建完整的文件路径
            file_path = os.path.join(directory, filename)
            print(f"正在处理文件: {file_path}")

            try:
                # 读取 shapefile 文件
                gdf = gpd.read_file(file_path)
                
                # 提取属性数据（去掉几何列）
                df = pd.DataFrame(gdf.drop(columns='geometry'))
                # df = pd.DataFrame(gdf)
                
                # 保存为 CSV 文件，使用与 .shp 文件相同的名字
                output_csv = os.path.join(directory, f"{os.path.splitext(filename)[0]}.csv")
                df.to_csv(output_csv, index=False)
                
                print(f"成功提取表格数据并保存为: {output_csv}")
            
            except Exception as e:
                print(f"处理文件 {file_path} 时出错: {e}")

# 指定当前文件夹作为工作目录
current_directory = os.getcwd()

# 调用函数进行处理
extract_shapefile_attributes_to_csv(current_directory)
