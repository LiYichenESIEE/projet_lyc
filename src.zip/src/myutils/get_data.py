# utils/get_data.py
import pandas as pd

# def fetch_data():
#     url = "https://example.com/air_quality.csv"  # demo
#     raw_data = pd.read_csv(url)
#     raw_data.to_csv('../data/raw/rawdata.csv', index=False)
#     return raw_data
