# utils/clean_data.py
import pandas as pd
import numpy as np
import geopandas as gpd

def clean_data():
    raw_data = pd.read_csv('../data/raw/rawdata.csv')
    cleaned_data = raw_data.dropna() 
    cleaned_data.to_csv('../data/cleaned/cleaneddata.csv', index=False)
    return cleaned_data

def load_and_process_data(income_shapefile, cvap_shapefile, election_shapefile):
    
    income_gdf = gpd.read_file(income_shapefile)
    cvap_gdf = gpd.read_file(cvap_shapefile)
    election_gdf = gpd.read_file(election_shapefile)

  
    income_gdf = income_gdf[['GEOID', 'MEDN_INC22', 'geometry']]
    income_gdf['GEOID'] = income_gdf['GEOID'].astype(str)
    income_gdf['MEDN_INC22'] = income_gdf['MEDN_INC22'].replace(-999999, np.nan)

 
    election_gdf = election_gdf[['GEOID20', 'G20PREDBID', 'G20PRERTRU', 'geometry']]
    election_gdf['GEOID20'] = election_gdf['GEOID20'].astype(str)

  
    cvap_gdf = cvap_gdf[['GEOID20', 'DIST', 'CVAP_TOT20', 'geometry']]
    cvap_gdf['GEOID20'] = cvap_gdf['GEOID20'].astype(str)

    income_with_district = gpd.sjoin(income_gdf, cvap_gdf, how='left', predicate='within')
    income_with_district = income_with_district.dropna(subset=['DIST'])
    district_income = income_with_district.groupby('DIST')['MEDN_INC22'].mean().reset_index()
    district_income.rename(columns={'DIST': 'District', 'MEDN_INC22': 'Median_Income'}, inplace=True)

    election_with_district = gpd.sjoin(election_gdf, cvap_gdf, how='left', predicate='within')
    election_with_district = election_with_district.dropna(subset=['DIST'])
    district_election = election_with_district.groupby('DIST').agg({
        'G20PREDBID': 'sum',
        'G20PRERTRU': 'sum'
    }).reset_index()
    district_election.rename(columns={'DIST': 'District', 'G20PREDBID': 'Votes_Biden', 'G20PRERTRU': 'Votes_Trump'}, inplace=True)

    district_cvap = cvap_gdf[['DIST', 'CVAP_TOT20']].rename(columns={'DIST': 'District', 'CVAP_TOT20': 'CVAP_Total'})


    merged_df = district_income.merge(district_election, on='District')
    merged_df = merged_df.merge(district_cvap, on='District')
    merged_df['Total_Votes'] = merged_df['Votes_Biden'] + merged_df['Votes_Trump']
    merged_df['Biden_Vote_Share'] = merged_df['Votes_Biden'] / merged_df['Total_Votes']
    merged_df['Trump_Vote_Share'] = merged_df['Votes_Trump'] / merged_df['Total_Votes']
    merged_df = merged_df.dropna()

    district_geometry = cvap_gdf[['DIST', 'geometry']].rename(columns={'DIST': 'District'})
    merged_gdf = merged_df.merge(district_geometry, on='District')
    merged_gdf = gpd.GeoDataFrame(merged_gdf, geometry='geometry')


    return merged_gdf