Massachusetts 2022 Select Income Data from the American Community Survey (2018-2022) at the Block Group level

##Redistricting Data Hub (RDH) Retrieval Date
03/13/24

##Sources
ACS data retrieved using the Census API: https://api.census.gov/data/2022/acs/acs5
Boundary shapefile retrieved from the Census Cartographic Boundary File website: https://www.census.gov/geographies/mapping-files/time-series/geo/carto-boundary-file.2022.html

##Fields
Field Name Description                                                                                                                               
GEOID      Unique Geographic Identifier                                                                                                              
STATEFP    State FIPS                                                                                                                                
STATE      State Name                                                                                                                                
COUNTYFP   County FIPS                                                                                                                               
COUNTY     County Name                                                                                                                               
MEDN_INC22 Median household income in past 12 months (in 2022 inflation-adjusted dollars) (B19013_001E)                                              
TOT_HOUS22 Total households (B19001_001E)                                                                                                            
LESS_10K22 Households with less than $10,000 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_002E)            
10K_15K22  Households with between $10,000 and $14,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_003E)  
15K_20K22  Households with between $15,000 and $19,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_004E)  
20K_25K22  Households with between $20,000 and $24,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_005E)  
25K_30K22  Households with between $25,000 and $29,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_006E)  
30K_35K22  Households with between $30,000 and $34,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_007E)  
35K_40K22  Households with between $35,000 and $39,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_008E)  
40K_45K22  Households with between $40,000 and $44,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_009E)  
45K_50K22  Households with between $45,000 and $49,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_010E)  
50K_60K22  Households with between $50,000 and $59,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_011E)  
60K_75K22  Households with between $60,000 and $74,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_012E)  
75K_100K22 Households with between $75,000 and $99,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_013E)  
100_125K22 Households with between $100,000 and $124,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_014E)
125_150K22 Households with between $125,000 and $149,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_015E)
150_200K22 Households with between $150,000 and $199,999 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_016E)
200K_MOR22 Households with more than $200,000 in household income in the past 12 months (in 2022 inflation-adjusted dollars) (B19001_017E)           

##Processing
ACS data for Massachusetts was retrieved with a Python script from the Census API.
The block group data is available by county for all counties in Massachusetts. The script extracted the data for all counties in Massachusetts. 
Each field represents an estimate from the Census for a particular variable, as noted in the Fields section above.
For MEDN_INC22, not all units have values and are recorded as -666666666 by the Census. These are stored as null values in this file, if applicable.
The data were then merged on the GEOID with a corresponding TIGER shapefile.

##Additional Notes
For any questions about this dataset or if you would like additional related ACS data, please email info@redistrictingdatahub.org.