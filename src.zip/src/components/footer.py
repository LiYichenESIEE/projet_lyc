from dash import dcc, html

footer = html.Footer(
    html.Div(
        [
            "Data source: United States",
            html.Br(),
            "2024-10"
        ],
        style={'text-align': 'center', 'padding': '10px'}
    )
)