# src/pages/home.py
import dash_bootstrap_components as dbc
from dash import dcc, html
import plotly.express as px
import pandas as pd
from src.components.component_geopandas import get_geo_chart
from src.components.chart import get_scatter_plots_chart,get_histograms_chart,get_fig_bar_bubble_chart
from src.myutils.clean_data import *
from src.components.footer import footer
from src.components.navbar import navbar

def home_layout(merged_gdf):
    geo_chart = get_geo_chart(merged_gdf)
    scatter_plots_chart = get_scatter_plots_chart(merged_gdf)
    histograms_chart = get_histograms_chart(merged_gdf)
    fig_bar_bubble_chart = get_fig_bar_bubble_chart(merged_gdf)
    layout = dbc.Container(
        fluid=True,
        children=[
            navbar,
            geo_chart,
            scatter_plots_chart,
            histograms_chart,
            fig_bar_bubble_chart,
            footer
        ]
    )
    return layout
