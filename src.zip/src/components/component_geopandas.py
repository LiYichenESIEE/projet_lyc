
import geopandas as gpd
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from shapely.geometry import Point
from sklearn.linear_model import LinearRegression
import re
import plotly.express as px
import dash_bootstrap_components as dbc
from dash import dcc, html
####################################
def create_interactive_map(merged_gdf):
    fig_income = px.choropleth(
        merged_gdf,
        geojson=merged_gdf.geometry,
        locations=merged_gdf.index,
        color='Median_Income',
        hover_name='District',
        color_continuous_scale='OrRd',
        labels={'Median_Income':'Median Income'}
    )
    fig_income.update_geos(fitbounds="locations", visible=False)

    fig_biden = px.choropleth(
        merged_gdf,
        geojson=merged_gdf.geometry,
        locations=merged_gdf.index,
        color='Biden_Vote_Share',
        hover_name='District',
        color_continuous_scale='Blues',
        labels={'Biden_Vote_Share':'Biden Vote Share'}
    )
    fig_biden.update_geos(fitbounds="locations", visible=False)

    fig_trump = px.choropleth(
        merged_gdf,
        geojson=merged_gdf.geometry,
        locations=merged_gdf.index,
        color='Trump_Vote_Share',
        hover_name='District',
        color_continuous_scale='Reds',
        labels={'Trump_Vote_Share':'Trump Vote Share'}
    )
    fig_trump.update_geos(fitbounds="locations", visible=False)

    return fig_income, fig_biden, fig_trump


def get_geo_chart(merged_gdf):
    fig_income, fig_biden, fig_trump = create_interactive_map(merged_gdf)
    geo_chart = dbc.Row(
                [
                    dbc.Col([
                        html.H3("Median Income by Congressional District"),
                        dcc.Graph(figure=fig_income)
                    ], width=4),
                    dbc.Col([
                        html.H3("Biden Vote Share by Congressional District"),
                        dcc.Graph(figure=fig_biden)
                    ], width=4),
                    dbc.Col([
                        html.H3("Trump Vote Share by Congressional District"),
                        dcc.Graph(figure=fig_trump)
                    ], width=4),
                ]
            )
    return geo_chart