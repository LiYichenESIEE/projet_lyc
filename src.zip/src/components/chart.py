# src/components/component1.py
from dash import dcc
import statsmodels.api as sm
import plotly.express as px
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import dcc, html

def create_scatter_plots(merged_df):
    fig_biden_scatter = px.scatter(
        merged_df, x='Median_Income', y='Biden_Vote_Share',
        title='Relationship between Median Income and Biden Vote Share',
        labels={'Median_Income': 'Median Household Income (USD)', 'Biden_Vote_Share': 'Biden Vote Share'},
        color_discrete_sequence=['blue']
    )

    fig_biden_scatter.add_trace(go.Scatter(
        x=merged_df['Median_Income'],
        y=sm.OLS(merged_df['Biden_Vote_Share'], sm.add_constant(merged_df['Median_Income'])).fit().fittedvalues,
        mode='lines',
        name='Regression Line',
        line=dict(color='darkblue')
    ))

    fig_trump_scatter = px.scatter(
        merged_df, x='Median_Income', y='Trump_Vote_Share',
        title='Relationship between Median Income and Trump Vote Share',
        labels={'Median_Income': 'Median Household Income (USD)', 'Trump_Vote_Share': 'Trump Vote Share'},
        color_discrete_sequence=['red']
    )

    fig_trump_scatter.add_trace(go.Scatter(
        x=merged_df['Median_Income'],
        y=sm.OLS(merged_df['Trump_Vote_Share'], sm.add_constant(merged_df['Median_Income'])).fit().fittedvalues,
        mode='lines',
        name='Regression Line',
        line=dict(color='darkred')
    ))

    return fig_biden_scatter, fig_trump_scatter

def create_histograms(merged_df):
    fig_biden_histogram = px.histogram(
        merged_df,
        x='Biden_Vote_Share',
        nbins=20,
        title='Distribution of Biden Vote Share',
        labels={'Biden_Vote_Share': 'Biden Vote Share'},
        color_discrete_sequence=['blue']
    )

    fig_trump_histogram = px.histogram(
        merged_df,
        x='Trump_Vote_Share',
        nbins=20,
        title='Distribution of Trump Vote Share',
        labels={'Trump_Vote_Share': 'Trump Vote Share'},
        color_discrete_sequence=['red']
    )

    return fig_biden_histogram, fig_trump_histogram

def create_bar_charts(merged_df):
    # Calculate the total votes for Biden and Trump
    biden_votes = merged_df['Votes_Biden'].sum()
    trump_votes = merged_df['Votes_Trump'].sum()

    # Create data suitable for the bar chart
    bar_data = {
        'Candidate': ['Biden', 'Trump'],
        'Total_Votes': [biden_votes, trump_votes]
    }
    
    # Create the bar chart to display the total votes
    fig_bar_chart = px.bar(
        bar_data,
        x='Candidate',
        y='Total_Votes',
        title='Total Votes of Biden and Trump',
        labels={'Total_Votes': 'Total Votes'},
        color='Candidate',
        color_discrete_map={'Biden': 'blue', 'Trump': 'red'}
    )

    return fig_bar_chart

def create_cool_bubble_chart(merged_df):
    # Add a column to determine candidate preference (Biden or Trump)
    merged_df['Candidate_Preference'] = merged_df.apply(
        lambda row: 'Biden' if row['Biden_Vote_Share'] > row['Trump_Vote_Share'] else 'Trump', axis=1
    )

    # Create the bubble chart
    fig_bubble_chart = px.scatter(
        merged_df,
        x='Median_Income',
        y='Biden_Vote_Share',
        size='Total_Votes', 
        color='Candidate_Preference', 
        hover_name='District',  
        title='Median Income vs. Biden Vote Share (Bubble Size by Total Votes)',
        labels={'Median_Income': 'Median Income', 'Biden_Vote_Share': 'Biden Vote Share'},
        color_discrete_map={'Biden': 'blue', 'Trump': 'red'}
    )
    
    # Set the chart’s visual effects
    fig_bubble_chart.update_traces(marker=dict(line=dict(width=1, color='DarkSlateGrey')))
    fig_bubble_chart.update_layout(
        title_font_size=24,
        xaxis_title_font_size=16,
        yaxis_title_font_size=16,
        legend_title_text='Candidate Preference',
        plot_bgcolor='rgba(0, 0, 0, 0.05)'
    )

    return fig_bubble_chart

def get_scatter_plots_chart(merged_df):
    fig_biden_scatter, fig_trump_scatter = create_scatter_plots(merged_df)
    scatter_chart = dbc.Row([
            dbc.Col([
            html.H3("Relationship between Median Income and Biden Vote Share"),
            dcc.Graph(figure=fig_biden_scatter)
             ], width=6),
            
            dbc.Col([
                    html.H3("Relationship between Median Income and Trump Vote Share"),
                    dcc.Graph(figure=fig_trump_scatter)
                    ], width=6),
        ])
    return scatter_chart

def get_histograms_chart(merged_df):
    fig_biden_histogram, fig_trump_histogram = create_histograms(merged_df)
    histograms_chart = dbc.Row([
            dbc.Col([
            html.H3("Relationship between Median Income and Biden Vote Share"),
            dcc.Graph(figure=fig_biden_histogram)
             ], width=6),
            
            dbc.Col([
                    html.H3("Relationship between Median Income and Trump Vote Share"),
                    dcc.Graph(figure=fig_trump_histogram)
                    ], width=6),
        ]) 
    return histograms_chart

def get_fig_bar_bubble_chart(merged_df):
    fig_bar_chart = create_bar_charts(merged_df)
    fig_bubble_chart = create_cool_bubble_chart(merged_df)
    bar_bubble_chart = dbc.Row([
            dbc.Col([
            html.H3("Relationship between Median Income and Biden Vote Share"),
            dcc.Graph(figure=fig_bar_chart)
             ], width=6),
            
            dbc.Col([
                    html.H3("Relationship between Median Income and Trump Vote Share"),
                    dcc.Graph(figure=fig_bubble_chart)
                    ], width=6),
        ])  
    return bar_bubble_chart