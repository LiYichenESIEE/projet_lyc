import dash_bootstrap_components as dbc

navbar = dbc.NavbarSimple(
    brand="Dashboard",
    brand_href="#",
    color="primary",
    dark=True,
)
